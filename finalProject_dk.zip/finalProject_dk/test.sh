#!/bin/sh
export WEBS="00 10 20 21"
export IPS="192.168.0.100 10.0.0.3 10.1.0.3 10.2.0.3"

for web in $WEBS; do for ip in $IPS; do echo "TEST $web -> $ip" &&  sudo nsenter -t `docker inspect -f '{{ .State.Pid }}' web650$web` -n mtr -c 3 -r $ip; done; done
