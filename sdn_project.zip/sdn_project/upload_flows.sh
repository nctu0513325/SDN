#!/bin/bash

DEVICE_ID_OVS1="of:0000000000000001"
DEVICE_ID_OVS2="of:0000000000000002"
ONOS_API="http://localhost:8181/onos/v1/flows"
AUTH="onos:rocks"

echo "🚀 正在上傳 Flow Rules 到 ONOS..."

# 對應 OVS1 的 flow rules
for file in \
  Ovs1ToR65020.json ovsone12.json\
  R65020ToOvs1.json; do
  echo "➡️ 上傳 $file 到 OVS1"
  curl -u $AUTH -X POST -H "Content-Type: application/json" \
    -d @flowrule/$file $ONOS_API/$DEVICE_ID_OVS1
done

# 對應 OVS2 的 flow rules
for file in \
  new1.json new2.json new3.json new4.json new5.json testtest.json 42.json 24.json ovstwo12.json \
  Ovs2ToR65010.json Ovs2ToR65021.json Ovs2ToSpeaker.json Ovs2ToWeb65000.json \
  SpeakerToOvs2.json Web65000ToOvs2.json ovs2to65020.json \
  Web65000ToR65021.json Web65021ToWeb65000.json; do
  echo "➡️ 上傳 $file 到 OVS2"
  curl -u $AUTH -X POST -H "Content-Type: application/json" \
    -d @flowrule/$file $ONOS_API/$DEVICE_ID_OVS2
done

echo "✅ 所有 Flow Rule 已上傳完畢"

